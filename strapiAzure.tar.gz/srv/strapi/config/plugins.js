// path: ./config/plugins.js

module.exports = ({ env }) => ({
  // restrict expire time in token
  'users-permissions': {
    config: {
      jwt: {
        expiresIn: '1h',
      },
    },
  },
  // graphQl
  'graphql': {
    enabled: true,
    config: {
      defaultLimit: 10,
      maxLimit: 20
    }
  },
  // Transforming response api
  'transformer': {
    enabled: true,
    config: {
      prefix: '/api/',
      responseTransforms: {
        removeAttributesKey: true,
        removeDataKey: true,
      }
    }
  },
//  // enable a plugin that doesn't require any configuration
//  i18n: true,
//  // active plugin Google Auth
//  'strapi-google-auth': {
//    enabled: true,
//  },

  // ..

});

