import React from 'react';
import { Redirect } from 'react-router-dom';

const CreatePage = () => {
  return <Redirect to="/404" />;
};

export default CreatePage;
