import { createContext } from 'react';

const LayoutDndContext = createContext();

export default LayoutDndContext;
